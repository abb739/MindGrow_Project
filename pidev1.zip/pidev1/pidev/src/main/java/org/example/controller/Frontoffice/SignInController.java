package org.example.controller.Frontoffice;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.embed.swing.SwingFXUtils;
import javafx.stage.Stage;
import org.example.entities.Utilisateur;
import org.example.services.UtilisateurService;
import org.example.services.GoogleAuthService;
import org.example.controller.Backoffice.AdminDashboardController;
import org.mindrot.jbcrypt.BCrypt;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

public class SignInController {

    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label errorLabel;

    // Nouveaux éléments pour le Captcha
    @FXML
    private ImageView captchaImageView;
    @FXML
    private TextField captchaField;
    private String currentCaptchaText;

    private final UtilisateurService utilisateurService = new UtilisateurService();

    @FXML
    public void initialize() {
        refreshCaptcha(null); // Afficher le Captcha dès le lancement
    }

    @FXML
    void refreshCaptcha(ActionEvent event) {
        currentCaptchaText = generateRandomString(5);
        BufferedImage image = createCaptchaImage(currentCaptchaText);
        Image fxImage = SwingFXUtils.toFXImage(image, null);
        if (captchaImageView != null) {
            captchaImageView.setImage(fxImage);
        }
        if (captchaField != null) {
            captchaField.clear();
        }
    }

    private String generateRandomString(int length) {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private BufferedImage createCaptchaImage(String text) {
        int width = 120;
        int height = 45;
        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = bufferedImage.createGraphics();

        g2d.setColor(new Color(240, 240, 240));
        g2d.fillRect(0, 0, width, height);

        Random r = new Random();
        g2d.setStroke(new BasicStroke(1.5f));
        for (int i = 0; i < 6; i++) {
            g2d.setColor(new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255)));
            g2d.drawLine(r.nextInt(width), r.nextInt(height), r.nextInt(width), r.nextInt(height));
        }

        g2d.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 24));
        for (int i = 0; i < text.length(); i++) {
            g2d.setColor(new Color(50 + r.nextInt(100), 50 + r.nextInt(100), 50 + r.nextInt(100)));
            int x = 15 + (i * 18);
            int y = 30 + r.nextInt(8) - 4;
            g2d.drawString(String.valueOf(text.charAt(i)), x, y);
        }

        g2d.dispose();
        return bufferedImage;
    }

    @FXML
    void handleSignIn(ActionEvent event) {
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String userCaptcha = captchaField != null ? captchaField.getText().trim() : "";

        if (email.isEmpty() || password.isEmpty() || userCaptcha.isEmpty()) {
            errorLabel.setText("Veuillez remplir tous les champs et le Captcha.");
            return;
        }

        if (!userCaptcha.equalsIgnoreCase(currentCaptchaText)) {
            errorLabel.setText("Captcha incorrect. Veuillez réessayer.");
            refreshCaptcha(null);
            return;
        }

        // Tentative d'authentification
        Utilisateur utilisateurConnecte = utilisateurService.authentifier(email, password);

        if (utilisateurConnecte != null) {
            connectUser(utilisateurConnecte, event);
        } else {
            errorLabel.setStyle("-fx-text-fill: red;");
            errorLabel.setText("Email ou mot de passe incorrect.");
        }
    }

    private void connectUser(Utilisateur u, ActionEvent event) {
        errorLabel.setStyle("-fx-text-fill: green;");
        errorLabel.setText("Connexion réussie ! Bienvenue " + u.getPrenom() + ".");

        try {
            FXMLLoader loader;
            Parent root;
            Scene scene;
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            if ("admin".equalsIgnoreCase(u.getRole())) {
                loader = new FXMLLoader(getClass().getResource("/Backoffice/AdminDashboard.fxml"));
                root = loader.load();
                AdminDashboardController adminControl = loader.getController();
                adminControl.initData(u);
                stage.setTitle("Espace Administrateur");
            } else {
                loader = new FXMLLoader(getClass().getResource("/Frontoffice/ClientDashboard.fxml"));
                root = loader.load();
                ClientDashboardController clientControl = loader.getController();
                clientControl.initData(u);
                stage.setTitle("Espace Client - MindGrow");
            }

            scene = new Scene(root);
            stage.setScene(scene);
            stage.setMaximized(true);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Erreur lors de la redirection vers votre espace.");
        }
        System.out.println("Utilisateur connecté : " + u);
    }

    @FXML
    void goToSignUp(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/Frontoffice/SignUp.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setMaximized(true);
            stage.setTitle("Inscription");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Erreur lors du chargement de la page d'inscription.");
        }
    }

    @FXML
    void goToForgotPassword(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/Frontoffice/ForgotPassword.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Mot de passe oublié");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Erreur lors du chargement de la page de récupération.");
        }
    }

    @FXML
    void handleGoogleAuth(ActionEvent event) {
        errorLabel.setStyle("-fx-text-fill: blue;");
        errorLabel.setText("Ouverture du navigateur pour connexion Google...");

        GoogleAuthService googleAuth = new GoogleAuthService();
        String googleEmail = googleAuth.authenticateAndGetEmail();

        if (googleEmail != null) {
            System.out.println("Google Auth réussi pour : " + googleEmail);

            // On cherche si l'utilisateur existe déjà
            boolean exists = utilisateurService.emailExiste(googleEmail);
            Utilisateur u = null;

            if (exists) {
                // S'il existe, on ne peut pas utiliser la méthode authentifier classique
                // car on n'a pas son mot de passe, mais on sait qu'il est légitime (Google l'a
                // vérifié).
                // On va "tricher" en récupérant l'utilisateur complet depuis la liste (ou
                // idéalement avec getByEmail)
                for (Utilisateur util : utilisateurService.afficherUtilisateurs()) {
                    if (util.getEmail().equalsIgnoreCase(googleEmail)) {
                        u = util;
                        break;
                    }
                }
            } else {
                // S'il n'existe pas, on lui crée un compte Client à la volée !
                String randomPassword = String.valueOf(System.currentTimeMillis()); // Mot de passe aléatoire
                u = new Utilisateur("User_" + System.currentTimeMillis() % 1000, "Google", googleEmail, randomPassword,
                        "client");

                // Hachage + Insertion
                String hash = BCrypt.hashpw(randomPassword, BCrypt.gensalt());
                u.setMotDePasse(hash);
                utilisateurService.ajouterUtilisateur(u);

                // On le recharge pour avoir son vrai ID depuis la BDD
                for (Utilisateur util : utilisateurService.afficherUtilisateurs()) {
                    if (util.getEmail().equalsIgnoreCase(googleEmail)) {
                        u = util;
                        break;
                    }
                }
            }

            // On lance la redirection
            if (u != null) {
                connectUser(u, event);
            } else {
                errorLabel.setStyle("-fx-text-fill: red;");
                errorLabel.setText("Erreur inattendue après connexion Google.");
            }

        } else {
            errorLabel.setStyle("-fx-text-fill: red;");
            errorLabel.setText("Échec ou annulation de la connexion Google.");
        }
    }
}
